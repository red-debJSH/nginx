let buttonMenu = document.getElementById('menu-icon')

buttonMenu.addEventListener('click', e =>{
    document.body.classList.toggle('animate')
})